import { loadRules } from "./rules.js";
import { classifyExecution, resolveRuleMatch } from "./classify.js";
import { isFileContentInspectionCommand } from "./command-identity.js";
import { normalizeExecutionInput } from "./execution-input.js";
import { clampTextMiddleWithMetadata, clampTextWithMetadata, countTextChars, dedupeAdjacent, headTail, normalizeLines, pluralize, stripAnsi, trimEmptyEdges } from "./text.js";
import { storeArtifact, storeArtifactMetadata } from "./artifacts.js";
import { NO_COMPACTION_METADATA, mergeCompactionMetadata, type CompactionMetadata } from "./compaction-metadata.js";
import { buildGithubActionsFailureSummary } from "./github-actions-summary.js";
import { rewriteGhLines, rewriteGitDiffLines, rewriteGitStatusLines, rewriteSearchLines } from "./reduce-formatters.js";
import { buildInspectionSummary } from "./reduce-inspection-summary.js";
import { compactWholeJsonText } from "./reduce-utils.js";

import type { CompactResult, CompiledRule, ReduceOptions, ToolExecutionInput } from "../types.js";

const TINY_OUTPUT_MAX_CHARS = 240;
const SMALL_OUTPUT_PASSTHROUGH_MIN_SAVED_CHARS = 120;
const SMALL_OUTPUT_PASSTHROUGH_MAX_RATIO = 0.75;

function buildRawText(input: ToolExecutionInput): string {
  if (input.combinedText) {
    return input.combinedText;
  }

  const stdout = input.stdout ?? "";
  const stderr = input.stderr ?? "";
  if (!stdout) {
    return stderr;
  }
  if (!stderr) {
    return stdout;
  }
  return `${stdout}\n${stderr}`;
}

function prettyPrintJsonIfPossible(text: string): string {
  const trimmed = text.trim();
  if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) {
    return text;
  }

  try {
    const parsed = JSON.parse(trimmed) as unknown;
    if (typeof parsed === "object" && parsed !== null) {
      return JSON.stringify(parsed, null, 2);
    }
  } catch {
    return text;
  }

  return text;
}

function applyRule(
  compiledRule: CompiledRule,
  input: ToolExecutionInput,
  rawText: string,
  noOmit = false,
): { summary: string; facts: Record<string, number>; compaction: CompactionMetadata } {
  const rule = compiledRule.rule;
  if (rule.transforms?.prettyPrintJson) {
    rawText = prettyPrintJsonIfPossible(rawText);
  }
  let lines = normalizeLines(rawText);
  const facts: Record<string, number> = {};

  if (rule.transforms?.stripAnsi) {
    lines = normalizeLines(stripAnsi(lines.join("\n")));
  }

  const outputMatchText = trimEmptyEdges(lines).join("\n");
  const matchedOutput = compiledRule.compiled.outputMatches.find((entry) => entry.pattern.test(outputMatchText));
  if (!noOmit && matchedOutput) {
    return {
      summary: matchedOutput.message,
      facts,
      compaction: NO_COMPACTION_METADATA,
    };
  }

  if (!noOmit && rule.filters?.skipPatterns?.length) {
    lines = lines.filter((line) => !compiledRule.compiled.skipPatterns.some((pattern) => pattern.test(line)));
  }

  let counterLines = [...lines];

  if (!noOmit && rule.filters?.keepPatterns?.length) {
    const kept = lines.filter((line) => compiledRule.compiled.keepPatterns.some((pattern) => pattern.test(line)));
    if (kept.length > 0) {
      lines = kept;
    }
  }

  if (rule.transforms?.trimEmptyEdges) {
    counterLines = trimEmptyEdges(counterLines);
    lines = trimEmptyEdges(lines);
  }

  if (!noOmit && rule.transforms?.dedupeAdjacent) {
    counterLines = dedupeAdjacent(counterLines);
    lines = dedupeAdjacent(lines);
  }

  if (rule.id === "git/status") {
    counterLines = rewriteGitStatusLines(counterLines);
    lines = rewriteGitStatusLines(lines);
  }
  const preRewriteLines = [...lines];
  let rewriteCompaction: CompactionMetadata | undefined;
  if (rule.id === "cloud/gh") {
    counterLines = rewriteGhLines(counterLines, input, noOmit).lines;
    const rewritten = rewriteGhLines(lines, input, noOmit);
    lines = rewritten.lines;
    rewriteCompaction = mergeCompactionMetadata(rewriteCompaction, rewritten.compaction);
  }
  if (rule.id === "search/rg") {
    const rewritten = rewriteSearchLines(lines, noOmit);
    lines = rewritten.lines;
    rewriteCompaction = mergeCompactionMetadata(rewriteCompaction, rewritten.compaction);
  }
  if (rule.id === "git/diff") {
    const rewritten = rewriteGitDiffLines(lines, noOmit);
    lines = rewritten.lines;
    rewriteCompaction = mergeCompactionMetadata(rewriteCompaction, rewritten.compaction);
  }

  for (const counter of compiledRule.compiled.counters) {
    const pattern = counter.pattern;
    let factLines = rule.counterSource === "preKeep" ? counterLines : rule.id === "git/diff" ? preRewriteLines : lines;
    if (rule.id === "git/diff" && (counter.name === "added line" || counter.name === "removed line")) {
      factLines = factLines.filter((line) => !line.startsWith("+++") && !line.startsWith("---"));
    }
    facts[counter.name] = factLines.filter((line) => pattern.test(line)).length;
  }

  if (lines.length === 0 && rule.onEmpty) {
    return {
      summary: rule.onEmpty,
      facts,
      compaction: rewriteCompaction ?? NO_COMPACTION_METADATA,
    };
  }

  const summarize = input.exitCode && input.exitCode !== 0 && rule.failure?.preserveOnFailure
    ? {
        head: rule.failure.head ?? 6,
        tail: rule.failure.tail ?? 12,
      }
    : {
        head: rule.summarize?.head ?? 6,
        tail: rule.summarize?.tail ?? 6,
      };

  const compacted = headTail(lines, summarize.head, summarize.tail, noOmit);
  return {
    summary: compacted.lines.join("\n").trim(),
    facts,
    compaction: mergeCompactionMetadata(rewriteCompaction, compacted.compaction),
  };
}

function buildPassthroughText(input: ToolExecutionInput, rawText: string): string {
  const normalized = trimEmptyEdges(normalizeLines(stripAnsi(rawText))).join("\n").trim();
  if (!normalized) {
    return "(no output)";
  }

  if (input.exitCode && input.exitCode !== 0) {
    return `exit ${input.exitCode}\n${normalized}`;
  }

  return normalized;
}

function buildLiteralPassthroughText(input: ToolExecutionInput, rawText: string): string {
  const normalized = stripAnsi(rawText).trimEnd();
  if (!normalized) {
    return buildPassthroughText(input, rawText);
  }

  if (input.exitCode && input.exitCode !== 0) {
    return `exit ${input.exitCode}\n${normalized}`;
  }

  return normalized;
}

function shouldKeepSmallOutput(
  classification: { family: string },
  input: ToolExecutionInput,
  rawChars: number,
  compactChars: number,
  maxInlineChars: number,
): boolean {
  if (rawChars === 0 || rawChars > maxInlineChars || (input.exitCode ?? 0) !== 0) {
    return false;
  }
  if (!isTerseDiscoveryCommand(classification, input)) {
    return false;
  }

  const savedChars = rawChars - compactChars;
  const ratio = rawChars === 0 ? 1 : compactChars / rawChars;
  return savedChars < SMALL_OUTPUT_PASSTHROUGH_MIN_SAVED_CHARS
    || ratio > SMALL_OUTPUT_PASSTHROUGH_MAX_RATIO;
}

function isTerseDiscoveryCommand(classification: { family: string }, input: ToolExecutionInput): boolean {
  const argv = input.argv ?? [];
  if (classification.family === "git-status") {
    return argv.some((arg) => arg === "--short" || arg === "-s" || arg.startsWith("--porcelain"));
  }
  if (classification.family === "git-remote") {
    return argv.includes("-v") || argv.includes("--verbose");
  }
  if (classification.family === "git-worktree") {
    return argv.includes("--porcelain");
  }
  return false;
}

function formatInline(
  classification: { family: string },
  input: ToolExecutionInput,
  summary: string,
  facts: Record<string, number>,
  noOmit = false,
): string {
  const factParts = Object.entries(facts)
    .filter(([, count]) => count > 0)
    .map(([name, count]) => pluralize(count, name));

  const lines: string[] = [];
  if (input.exitCode && input.exitCode !== 0) {
    lines.push(`exit ${input.exitCode}`);
  }

  const shouldIncludeFacts = classification.family === "search"
    || (
      classification.family !== "git-status"
      && classification.family !== "help"
      && (noOmit || summary.includes("omitted"))
    )
    || (classification.family === "test-results" && (input.exitCode ?? 0) !== 0);

  if (shouldIncludeFacts && factParts.length > 0) {
    lines.push(factParts.join(", "));
  }
  lines.push(summary);
  return lines.join("\n").trim();
}

function selectInlineText(
  classification: { family: string },
  input: ToolExecutionInput,
  rawText: string,
  compactText: string,
  maxInlineChars: number,
  compactCompaction: CompactionMetadata,
  noOmit = false,
): { text: string; compaction: CompactionMetadata } {
  const passthroughText = buildPassthroughText(input, rawText);
  const rawChars = countTextChars(stripAnsi(rawText));
  const compactChars = countTextChars(compactText);
  if (noOmit) {
    return {
      text: compactText,
      compaction: compactCompaction,
    };
  }
  if (shouldKeepSmallOutput(classification, input, rawChars, compactChars, maxInlineChars)) {
    return {
      text: buildLiteralPassthroughText(input, rawText),
      compaction: NO_COMPACTION_METADATA,
    };
  }
  if (classification.family === "git-status") {
    return {
      text: compactText,
      compaction: compactCompaction,
    };
  }
  if (rawChars <= maxInlineChars && compactChars >= rawChars) {
    return {
      text: passthroughText,
      compaction: NO_COMPACTION_METADATA,
    };
  }
  const passthroughLimit = classification.family === "help" ? maxInlineChars : TINY_OUTPUT_MAX_CHARS;
  if (countTextChars(passthroughText) > passthroughLimit) {
    return {
      text: compactText,
      compaction: compactCompaction,
    };
  }
  if (countTextChars(passthroughText) <= countTextChars(compactText)) {
    return {
      text: passthroughText,
      compaction: NO_COMPACTION_METADATA,
    };
  }
  return {
    text: compactText,
    compaction: compactCompaction,
  };
}

export async function reduceExecution(input: ToolExecutionInput, opts: ReduceOptions = {}): Promise<CompactResult> {
  const rules = await loadRules(opts.cwd ? { cwd: opts.cwd } : undefined);
  return reduceExecutionWithRules(input, rules, opts);
}

export async function reduceExecutionWithRules(
  input: ToolExecutionInput,
  rules: CompiledRule[],
  opts: ReduceOptions = {},
): Promise<CompactResult> {
  const normalizedInput = normalizeExecutionInput(input);
  const rawText = buildRawText(normalizedInput);
  const measuredRawChars = countTextChars(stripAnsi(rawText));
  const maxInlineChars = opts.maxInlineChars ?? 1200;
  const buildStats = (reducedChars: number): CompactResult["stats"] => ({
    rawChars: measuredRawChars,
    reducedChars,
    ratio: measuredRawChars === 0 ? 1 : reducedChars / measuredRawChars,
  });
  const resolvedMatch = opts.classifier
    ? undefined
    : resolveRuleMatch(input, rules);
  const classification = resolvedMatch?.classification
    ?? classifyExecution(input, rules, opts.classifier);
  const reducerInput = resolvedMatch?.candidateInput ?? normalizedInput;
  const trace = opts.trace
    ? {
        ...(normalizedInput.command ? { normalizedCommand: normalizedInput.command } : {}),
        ...(normalizedInput.argv?.length ? { normalizedArgv: normalizedInput.argv } : {}),
        ...(reducerInput.command && reducerInput.command !== normalizedInput.command
          ? { reducerCommand: reducerInput.command }
          : {}),
        ...(reducerInput.argv?.length && reducerInput.argv !== normalizedInput.argv
          ? { reducerArgv: reducerInput.argv }
          : {}),
        ...(classification.matchedReducer ? { matchedReducer: classification.matchedReducer } : {}),
        family: classification.family,
      }
    : undefined;

  if (opts.raw) {
    const rawRef = opts.store
      ? await storeArtifact(
          {
            input: normalizedInput,
            rawText,
            classification,
            stats: {
              rawChars: measuredRawChars,
              reducedChars: measuredRawChars,
              ratio: 1,
            },
          },
          opts.storeDir,
        )
      : undefined;
    if (!opts.store && opts.recordStats) {
      await storeArtifactMetadata(
        {
          input: normalizedInput,
          rawText,
          classification,
          stats: {
            rawChars: measuredRawChars,
            reducedChars: measuredRawChars,
            ratio: 1,
          },
        },
        opts.storeDir,
      );
    }

    return {
      inlineText: rawText,
      compaction: NO_COMPACTION_METADATA,
      ...(trace ? { trace } : {}),
      ...(rawRef ? { rawRef } : {}),
      stats: {
        rawChars: measuredRawChars,
        reducedChars: measuredRawChars,
        ratio: 1,
      },
      classification,
    };
  }

  const inspectionSummary = buildInspectionSummary(normalizedInput, rawText, opts.noOmit);
  if (inspectionSummary) {
    const summaryText = inspectionSummary.lines.join("\n").trim();
    const selectedText = clampTextMiddleWithMetadata(summaryText, maxInlineChars, opts.noOmit);
    const reducedChars = countTextChars(selectedText.text);
    const summaryClassification = {
      family: "structured-summary",
      confidence: 0.9,
      matchedReducer: inspectionSummary.matchedReducer,
    };
    const stats = {
      rawChars: measuredRawChars,
      reducedChars,
      ratio: measuredRawChars === 0 ? 1 : reducedChars / measuredRawChars,
    };
    const rawRef = opts.store
      ? await storeArtifact(
          {
            input: normalizedInput,
            rawText,
            classification: summaryClassification,
            stats,
          },
          opts.storeDir,
        )
      : undefined;

    if (!opts.store && opts.recordStats) {
      await storeArtifactMetadata(
        {
          input: normalizedInput,
          rawText,
          classification: summaryClassification,
          stats,
        },
        opts.storeDir,
      );
    }

    return {
      inlineText: selectedText.text,
      previewText: summaryText,
      compaction: mergeCompactionMetadata(inspectionSummary.compaction, selectedText.compaction),
      ...(trace ? { trace } : {}),
      ...(rawRef ? { rawRef } : {}),
      stats,
      classification: summaryClassification,
    };
  }

  if (classification.matchedReducer === "generic/fallback" && isFileContentInspectionCommand(normalizedInput)) {
    if (!opts.store && opts.recordStats) {
      await storeArtifactMetadata(
        {
          input: normalizedInput,
          rawText,
          classification,
          stats: {
            rawChars: measuredRawChars,
            reducedChars: measuredRawChars,
            ratio: 1,
          },
        },
        opts.storeDir,
      );
    }

    return {
      inlineText: rawText,
      compaction: NO_COMPACTION_METADATA,
      ...(trace ? { trace } : {}),
      stats: {
        rawChars: measuredRawChars,
        reducedChars: measuredRawChars,
        ratio: 1,
      },
      classification,
    };
  }

  const matchedRule = rules.find((rule) => rule.rule.id === classification.matchedReducer)
    ?? rules.find((rule) => rule.rule.id === "generic/fallback");

  if (!matchedRule) {
    throw new Error("missing generic fallback rule");
  }

  const githubActionsFailureSummary = classification.matchedReducer === "generic/fallback"
    ? buildGithubActionsFailureSummary(reducerInput, rawText, opts.noOmit)
    : null;
  if (githubActionsFailureSummary) {
    const inlineText = clampTextMiddleWithMetadata(githubActionsFailureSummary.text, maxInlineChars, opts.noOmit);
    const reducedChars = countTextChars(inlineText.text);
    const stats = {
      rawChars: measuredRawChars,
      reducedChars,
      ratio: measuredRawChars === 0 ? 1 : reducedChars / measuredRawChars,
    };
    const rawRef = opts.store
      ? await storeArtifact(
          {
            input: normalizedInput,
            rawText,
            classification,
            stats,
          },
          opts.storeDir,
        )
      : undefined;

    if (!opts.store && opts.recordStats) {
      await storeArtifactMetadata(
        {
          input: normalizedInput,
          rawText,
          classification,
          stats,
        },
        opts.storeDir,
      );
    }

    return {
      inlineText: inlineText.text,
      previewText: githubActionsFailureSummary.text,
      compaction: mergeCompactionMetadata(githubActionsFailureSummary.compaction, inlineText.compaction),
      ...(trace ? { trace } : {}),
      ...(rawRef ? { rawRef } : {}),
      stats,
      classification,
    };
  }

  if (classification.matchedReducer === "generic/fallback") {
    const exitPrefix = reducerInput.exitCode && reducerInput.exitCode !== 0 ? `exit ${reducerInput.exitCode}\n` : "";
    const jsonBudget = Math.max(0, maxInlineChars - countTextChars(exitPrefix));
    const jsonOutput = compactWholeJsonText(rawText, jsonBudget, opts.noOmit);
    if (jsonOutput) {
      const inlineText = `${exitPrefix}${jsonOutput.text}`;
      const reducedChars = countTextChars(inlineText);
      const jsonClassification = {
        family: "structured-json",
        confidence: 0.9,
        matchedReducer: "generic/json",
        ...(classification.matchedVia ? { matchedVia: classification.matchedVia } : {}),
        ...(classification.matchedCommand ? { matchedCommand: classification.matchedCommand } : {}),
      };
      const stats = buildStats(reducedChars);
      const rawRef = opts.store
        ? await storeArtifact(
            {
              input: normalizedInput,
              rawText,
              classification: jsonClassification,
              stats,
            },
            opts.storeDir,
          )
        : undefined;

      if (!opts.store && opts.recordStats) {
        await storeArtifactMetadata(
          {
            input: normalizedInput,
            rawText,
            classification: jsonClassification,
            stats,
          },
          opts.storeDir,
        );
      }

      return {
        inlineText,
        ...(jsonOutput.compaction ? { compaction: jsonOutput.compaction } : {}),
        ...(trace ? { trace: { ...trace, matchedReducer: jsonClassification.matchedReducer, family: jsonClassification.family } } : {}),
        ...(rawRef ? { rawRef } : {}),
        stats,
        classification: jsonClassification,
      };
    }
  }

  const { summary, facts, compaction } = applyRule(matchedRule, reducerInput, rawText, opts.noOmit);
  const compactText = formatInline(classification, reducerInput, summary || "(no output)", facts, opts.noOmit);
  const selectedText = selectInlineText(classification, reducerInput, rawText, compactText, maxInlineChars, compaction, opts.noOmit);
  const clamp = classification.family === "help" || selectedText.text.includes("\n") ? clampTextMiddleWithMetadata : clampTextWithMetadata;
  const inlineText = clamp(selectedText.text, maxInlineChars, opts.noOmit);
  const reducedChars = countTextChars(inlineText.text);
  const stats = {
    rawChars: measuredRawChars,
    reducedChars,
    ratio: measuredRawChars === 0 ? 1 : reducedChars / measuredRawChars,
  };
  const rawRef = opts.store
    ? await storeArtifact(
        {
          input: normalizedInput,
          rawText,
          classification,
          stats,
        },
        opts.storeDir,
      )
    : undefined;

  if (!opts.store && opts.recordStats) {
    await storeArtifactMetadata(
      {
        input: normalizedInput,
        rawText,
        classification,
        stats,
      },
      opts.storeDir,
    );
  }

  return {
    inlineText: inlineText.text,
    ...(summary ? { previewText: summary } : {}),
    ...(Object.keys(facts).length > 0 ? { facts } : {}),
    compaction: mergeCompactionMetadata(selectedText.compaction, inlineText.compaction),
    ...(trace ? { trace } : {}),
    ...(rawRef ? { rawRef } : {}),
    stats,
    classification,
  };
}

export async function classifyOnly(input: ToolExecutionInput, forcedRuleId?: string) {
  const rules = await loadRules();
  return classifyExecution(input, rules, forcedRuleId);
}

export async function findMatchingRule(input: ToolExecutionInput): Promise<CompiledRule | undefined> {
  const rules = await loadRules();
  return resolveRuleMatch(input, rules)?.rule;
}
