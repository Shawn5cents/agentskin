import type { ToolExecutionInput } from "../types.js";

export const UNKNOWN_ARTIFACT_SOURCE = "unknown";
export const DEFAULT_CLI_ARTIFACT_SOURCE = "cli";

export function normalizeArtifactSource(value: unknown): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const source = value
    .trim()
    .toLowerCase()
    .replace(/[_\s]+/gu, "-")
    .replace(/[^a-z0-9.-]+/gu, "-")
    .replace(/^-+|-+$/gu, "");

  if (!source) {
    return null;
  }

  if (source.startsWith("amazon-q") || source.startsWith("amazonq") || source.startsWith("aws-q")) {
    return "amazon-q";
  }
  if (source.startsWith("claude-code") || source === "claude") {
    return "claude-code";
  }
  if (source.startsWith("cline")) {
    return "cline";
  }
  if (source.startsWith("codex")) {
    return "codex";
  }
  if (source.startsWith("command-code") || source.startsWith("commandcode")) {
    return "command-code";
  }
  if (source.startsWith("copilot-agent") || source.startsWith("github-copilot-agent")) {
    return "copilot-agent";
  }
  if (source.startsWith("copilot-cli") || source.startsWith("github-copilot-cli")) {
    return "copilot-cli";
  }
  if (source.startsWith("crush")) {
    return "crush";
  }
  if (source.startsWith("cursor")) {
    return "cursor";
  }
  if (source.startsWith("droid") || source.startsWith("factory-droid")) {
    return "droid";
  }
  if (source.startsWith("gemini")) {
    return "gemini-cli";
  }
  if (source.startsWith("grok-build") || source.startsWith("grokbuild") || source.startsWith("xai-grok-build")) {
    return "grok-build";
  }
  if (source.startsWith("grok")) {
    return "grok-cli";
  }
  if (source.startsWith("goose")) {
    return "goose";
  }
  if (source.startsWith("antigravity") || source === "google-antigravity") {
    return "antigravity";
  }
  if (source.startsWith("augment") || source.startsWith("auggie")) {
    return "augment";
  }
  if (source.startsWith("openclaw")) {
    return "openclaw";
  }
  if (source.startsWith("openhands")) {
    return "openhands";
  }
  if (source.startsWith("openinterpreter") || source.startsWith("open-interpreter")) {
    return "open-interpreter";
  }
  if (source.startsWith("openwebui") || source.startsWith("open-webui")) {
    return "openwebui";
  }
  if (source.startsWith("opencode") || source.startsWith("open-code")) {
    return "opencode";
  }
  if (source.startsWith("pi")) {
    return "pi";
  }
  if (source.startsWith("plandex")) {
    return "plandex";
  }
  if (source.startsWith("qoder")) {
    return "qoder";
  }
  if (source.startsWith("qwen")) {
    return "qwen-code";
  }
  if (source.startsWith("kimi")) {
    return "kimi";
  }
  if (source.startsWith("mux")) {
    return "mux";
  }
  if (source.startsWith("ruler")) {
    return "ruler";
  }
  if (source.startsWith("vscode-copilot") || source.startsWith("vs-code-copilot")) {
    return "vscode-copilot";
  }
  if (source === "direct" || source === "tokenjuice" || source === "wrap") {
    return DEFAULT_CLI_ARTIFACT_SOURCE;
  }

  return source;
}

export function resolveArtifactSource(input: ToolExecutionInput): string {
  return normalizeArtifactSource(input.metadata?.source) ?? DEFAULT_CLI_ARTIFACT_SOURCE;
}

export function readStoredArtifactSource(source: string | undefined): string {
  return normalizeArtifactSource(source) ?? UNKNOWN_ARTIFACT_SOURCE;
}
